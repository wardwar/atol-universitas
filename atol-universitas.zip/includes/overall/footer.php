      	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	    <script src="<?=Url::base()?>js/jquery-1.11.1.min.js"></script>
	    <!-- Include all compiled plugins (below), or include individual files as needed -->
	    <script src="<?=Url::base()?>js/bootstrap.min.js"></script>
	    <script src="<?=Url::base()?>js/script.js"></script>
	    <script src="<?=Url::base()?>js/sb-admin.js"></script>
	    <script src="<?=Url::base()?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

  </body>
</html>