<?php
class Url {
	public static function base(){
		return ("http://" . $_SERVER['SERVER_NAME']."/github/atol-universitas/");
	}
}