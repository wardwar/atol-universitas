<?php
class Dosen extends User {
	
}